<?php include '../../../wp-load.php'; ?>
<?php 
	$brand = $_POST['brand'];
	$year = $_POST['year'];
	$ref_no = $_POST['ref_no'];
	$category = $_POST['category'];
	$model = $_POST['model'];
	$meta_query = array();
	$tax_query = array();
	if($year != ''){
		$meta_query[] = array(
				'key' => 'yearofwatch',
				'value' => $year,
				'compare'=> '=',
				);
	}
	if($ref_no != ''){
		$meta_query[] = array(
				'key' => 'referencenumber',
				'value' => $ref_no,
				'compare'=> '=',
				);
	}
	if($model != ''){
		$meta_query[] = array(
				'key' => 'modelofwatch',
				'value' => $model,
				'compare'=> '=',
				);
	}
	if($category != ''){
		$tax_query[] = array(
					'taxonomy' => 'listing',
					'field' => 'term_id',
					'terms' => $category,
					);
	}
	if($brand != ''){
		$tax_query[] = array(
					'taxonomy' => 'brands',
					'field' => 'term_id',
					'terms' => $brand,
					);
	}
	$args = array(
    'post_type' => 'listing_type',
    'post_per_page' => -1,
    'meta_query' => $meta_query,
    'tax_query' => $tax_query,
	 );
	
	$postslist = get_posts( $args );
	//echo $wpdp->last_query;
	//echo "<pre>";print_r($postslist); echo "</pre>";
	if(!empty($postslist)){
	foreach($postslist as $list){
?>

<div class="itemdata icons itemid427 col-md-3 col-sm-6 col-xs-12 item-<?php echo $list->ID;?> col-xs-12">
<div class="thumbnail clearfix" style="height: 328px;">
   <div class="galleryframe frame">
			<div class="overlay-gallery">
				<div class="lbox">
					<a href="<?php  echo $featured_img_url = get_the_post_thumbnail_url($list->ID,'full'); ?>" data-gal="prettyPhoto[ppt_gal_<?php echo $list->ID?>]"><span class="fa fa-camera"></span></a><a href="<?php echo get_permalink($list->ID);?>"><span class="fa fa-search"></span></a>
				</div>
			</div> 
			<img src="<?php echo $featured_img_url;?>"></div><a href="<?php echo $featured_img_url; ?>" class="prettyPhoto" data-gal="prettyPhoto[ppt_gal_<?php echo $list->ID; ?>]" ></a> 
    <div class="content">  
    <h3><a href="<?php echo get_permalink($list->ID);?>"><span><?php echo  $list->post_title;?></span></a> <span id="wlt_star_665059840983427" class="wlt_starrating pull-right" style="cursor: pointer;"><span class="fa fa-star-o size16 readonlyfalse" data-score="1" title="bad"></span><span class="fa fa-star-o size16 readonlyfalse" data-score="2" title="poor"></span><span class="fa fa-star-o size16 readonlyfalse" data-score="3" title="regular"></span><span class="fa fa-star-o size16 readonlyfalse" data-score="4" title="good"></span><span class="fa fa-star-o size16 readonlyfalse" data-score="5" title="very good"></span><input name="score" type="hidden"></span>
		
				<script type="text/javascript">jQuery(document).ready(function(){ 
				jQuery('#wlt_star_665059840983427').raty({
				path: 'http://223.196.72.250/prochronos/wp-content/themes/studioluc/framework/img/rating/',
				score: 0,size: 16, click: function(score, evt) {			 
					WLTSaveRating('223.196.72.250/prochronos', '<?php echo $list->ID?>', score, 'wlt_star_665059840983427');
				}}); }); </script></h3>
    <div class="row">
    <div class="col-md-6 col-sm-6 col-xs-6"> <b><?php echo get_post_meta($list->ID,'price_current',true);?>€</b>  </div>
    <div class="col-md-6 col-sm-6 col-xs-6 text-right"> <span class="wlt_shortcode_category"><a href="http://223.196.72.250/prochronos/listing-category/automatic-watches/" rel="tag"><?php $term = get_term_by('id', $category, 'listing'); ?></a></span> <span class="bids">0 bids</span>    </div>
    </div>
 	<div class="line1"></div> 
       
    <span class="wlt_shortcode_excerpt"><?php echo $list->content;?>
</span>
<?php $expire = get_post_meta($list->ID,'listing_expiry_date', true);?>


 <script>
			
			jQuery(document).ready(function() {		
			var dateStr ='<?php echo $expire;?>';
			var a=dateStr.split(' ');
			var d=a[0].split('-');
			var t=a[1].split(':');
			var date1 = new Date(d[0],(d[1]-1),d[2],t[0],t[1],t[2]);
			console.log(date1);		
			//alert(date1);	 
				
					jQuery('#timecounter<?php echo $list->ID;?>').countdown({timezone: 1, until: date1, onExpiry: WLTvalidateexpiry<?php echo $list->ID;?> });

			});
			
			function WLTvalidateexpiry<?php echo  $list->ID;?>(){  setTimeout(function(){ CoreDo('<?php echo site_url();?>/?core_aj=1&amp;action=validateexpiry&amp;pid=<?php echo $list->ID; ?>', 'timeleft_4271511499638608658'); jQuery('#timeleft_4271511499638608658_wrap').html('&lt;div class=ea_finished&gt;&lt;span class=aetxt&gt;Auction Finished&lt;/span&gt;&lt;/div&gt;'); }, 1000);  };
			
			</script>
			
			<span class="timecounter" id="timecounter<?php echo $list->ID;?>"></span>


    
   
    
    </div>
       
    </div> 
 
</div>
<?php }
}
else{
	?> 0
	

	<?php }

 ?>
