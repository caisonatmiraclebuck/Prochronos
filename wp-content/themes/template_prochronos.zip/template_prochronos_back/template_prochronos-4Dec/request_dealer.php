<?php
/*
Template Name: [Request Dealers]
*/
/* =============================================================================
   [PREMIUMPRESS FRAMEWORK] THIS FILE SHOULD NOT BE EDITED
   ========================================================================== */
if (!defined('THEME_VERSION')) {	header('HTTP/1.0 403 Forbidden'); exit; }
/* ========================================================================== */
global  $userdata, $CORE; get_currentuserinfo();  $GLOBALS['flag-members'] = 1; 
/* =============================================================================
   LOAD PAGE TEMPLATE
   ========================================================================== */
   
// RANDOM NUMBERS


/* =============================================================================
   PAGE ACTIONS // 
   ========================================================================== */

// no index for report page

// LOAD HEADER   

$page_body 		= get_post_meta($post->ID, 'body', true);
if($page_body == "remove"){
	$GLOBALS['wlt_remove_body'] = true;
} 

// MOBILE VIEW HOME PAGE
if(defined('IS_MOBILEVIEW')){ 
include("home-mobile.php");
}else{	
?>
<?php get_header($CORE->pageswitch()); ?>
<?php hook_page_before(); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); 

	if($_POST['submit']){
		
		$brand = $_POST['brand'];
		$brand = get_term_by('id', $brand, 'brands');
		$brand_id = $brand->term_id;
		$model = $_POST['model'];
		$year = $_POST['year'];
		$type_of_watch = $_POST['type_of_watch'];
		$type_of_watch = get_term_by('id', $type_of_watch, 'listing');
		$category = $type_of_watch->term_id;
		$ref_no = $_POST['ref_no'];
		$gender = $_POST['gender'];
		$request_condition = $_POST['request_condition'];
		$req_country = $_POST['req_country'];
		$request_date = $_POST['request_date'];
		$request_existance = $_POST['request_existance'];
		$requester_email = 'nrawat@getyoursolutions.com';
		//$date = "Mar 03, 2011";
		$date = strtotime($request_date);
		$request_existance = strtotime("+$request_existance day", $date);
		//echo $table_prefix.'request_management';
		$insert = $wpdb->insert($table_prefix.'request_management', array(
			'brand' => $brand_id,
			'model' => $model,
			'year' => $year, 
			'type_of_watch' => $category, 
			'ref_no' => $ref_no, 
			'gender' => $gender, 
			'request_condition' => $request_condition, 
			'request_date' => $request_date, 
			'request_existance' => $request_existance, 
			'requester_email' => $requester_email, 
			'req_status' => 0, 
			'request_created' => date('Y-m-d h:i:s'), 
		));
	  $all_dealers = get_users('role=subscriber');
	  foreach($all_dealers as $dealer){
		 $email = $dealer->user_email;
		 // $email = 'nrawat@getyoursolutions.com';
		//  $to = $email;
         $subject = "New Request Has been Created";
         $message = "<b>Dear Watch Dealer</b><br> ";
         $message .= "<b>New request has been created following are the details</b><br><br>";
         if($brand != ''){
			 $message .= 'Brand: '.$brand->name.'<br>';
		 }
         if($model != ''){
			 $message .= 'Model: '.$model.'<br>';
		 }
         if($type_of_watch != ''){
			 $message .= 'Type of Watch: '.$type_of_watch->name.'<br>';
		 }
         if($brand != ''){
			 $message .= 'Launch Year: '.$year.'<br>';
		 }
         if($ref_no != ''){
			 $message .= 'Reference No: '.$ref_no.'<br>';
		 }
         if($gender != ''){
			 $message .= 'Gender: '.$gender.'<br>';
		 }
         if($request_condition != ''){
			 $message .= 'Condition of Watch: '.$request_condition.'<br>';
		 }
         if($request_existance != ''){
			 $message .= 'Time Period of Request Existance: '.$request_existance.'<br>';
		 }
		 $message .='<br><br>Kindly Regards,<br>Prochronos Team'; 
         
         $header = "From:".$requester_email."\r\n";
        // $header .= "Cc:afgh@somedomain.com \r\n";
         $header .= "MIME-Version: 1.0\r\n";
         $header .= "Content-type: text/html\r\n";
         
         $retval = wp_mail($email,$subject,$message,$header);
         
			//echo $retval;
	  }
	    if( $retval == true ) {
            echo "Request sent successfully...";
         }else {
            echo "Request could not be sent...";
         }

	}


?>

<div class="panel panel-default">
    <div class="panel-heading">
        <?php the_title(); ?>
    </div>
    <div class="panel-body">
        <?php // if ( has_post_thumbnail() ) { ?>
        <?php the_post_thumbnail('full',array("class" => "img-polaroid")); ?>
        
        <hr /> 
        <?php // } ?>
        <?php //the_content(); ?>
        <div class="requestFormCont row">
				
					<div class="form-group custom-group col-md-4 col-sm-6 col-xs-12">
						<label for="email">Brand:<span class="redAs">*</span></label>
						<div class="inputBox">
							  <select name="brand" class="form-control brand_data" tabindex="21" id="reg_field_brand">
								  	<option value=""></option>
									 <?php $terms = get_terms( array(
									'taxonomy' => 'brands',
									'hide_empty' => false
								) ); 
								foreach($terms as $term){
									
								?><option value="<?php echo $term->term_id;?>"><?php echo $term->name;?></option>
								<?php } ?>
							</select>
						</div>
					</div>
					<div class="form-group custom-group col-md-4 col-sm-6 col-xs-12">
						<label for="pwd">Model:</label>
						<input type="text" class="form-control model_data" id="pwd" placeholder="Enter Model" name="model">
					</div>
					<div class="form-group custom-group col-md-4 col-sm-6 col-xs-12">
						<label for="pwd">Category:</label>
						
						<div class="inputBox">
							<select name ="type_of_watch"  class="form-control category_data">
								<option value=""></option>
                           <?php $terms = get_terms( array(
									'taxonomy' => 'listing',
									'hide_empty' => false
								) ); 
								foreach($terms as $term){
									
							?><option value="<?php echo $term->term_id;?>"><?php echo $term->name;?></option>
							<?php } ?>
							</select>
						</div>
					</div>
					<div class="form-group custom-group col-md-4 col-sm-6 col-xs-12">
						<label for="pwd">Reference number:</label>
						<input type="text" class="form-control ref_no_data" id="pwd" placeholder="Enter Reference number" name="ref_no">
					</div>
					<div class="form-group custom-group col-md-4 col-sm-6 col-xs-12">
						<label for="pwd">Year:</label>
						<input type="text" class="form-control year_data" id="pwd" placeholder="Enter Year" name="year">
					</div>
					<div class="form-group custom-group col-md-4 col-sm-6 col-xs-12">
						<button  class="btn btn-default requestSearch ">Search</button>
						<button  class="btn btn-default requestSearch ">Leave Request</button>
					</div>
        </div>
   
   <div class="col-sm-12" style="">        
		<div class=" wlt_search_results grid_style wlt_builder_listings">
		<div class="request_Form" style="display:none">
		<h3>Sorry , No listing Found</h3>
	    You can leave a request for a specific watch by filling in the form below. You will receive an e-mail notification if a listing is created on our website that matches this requested watch.
	  <div class="requestFormCont">
                <form method="post" action = "">
                <h2>*Leave a request </h2>
                    <div class="form-group">
                        <label for="Brand">Brand:</label>
                        <div class="inputBox">
                            <select name="brand" class="form-control" tabindex="21" id="reg_field_brand">
								<option value=""></option>
									 <?php $terms = get_terms( array(
									'taxonomy' => 'brands',
									'hide_empty' => false
								) ); 
								foreach($terms as $term){
									
							?><option value="<?php echo $term->term_id;?>"><?php echo $term->name;?></option>
							<?php } ?>
								</select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Model">Model:</label>
                        <div class="inputBox">
                            <input type="text" class="form-control" id="" name="model" placeholder="Model ">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Category">Category:</label>
                        <div class="inputBox">
							<select name ="type_of_watch"  class="form-control">
								<option value=""></option>
                           <?php $terms = get_terms( array(
									'taxonomy' => 'listing',
									'hide_empty' => false
								) ); 
								foreach($terms as $term){
									
							?><option value="<?php echo $term->term_id;?>"><?php echo $term->name;?></option>
							<?php } ?>
							</select>
						</div>
                    </div>
                    <div class="form-group">
                        <label for="Referencenumber">Reference number:</label>
                        <div class="inputBox">
                            <input type="text" name="ref_no" class="form-control" id="" placeholder="Reference number">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Year">Year:</label>
                        <div class="inputBox">
                            <input type="text" class="form-control" id="" name= "year" placeholder="Year">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Gender">Gender:</label>
                        <div class="inputBox">
                            <div class="radioGroup"> <span class="genderRadio"> <input class="form-check-input" type="radio" name="gender" id="" value="Men"> Men
                               
                                </span> <span class="genderRadio"><input class="form-check-input" type="radio" name="gender" id="" value="Ladies"> Ladies
                                
                                </span> <span class="genderRadio">  <input class="form-check-input" type="radio" name="gender" id="" value="Unisex "> Unisex
                              
                                </span> </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Condition ">Condition :</label>
                        <div class="inputBox">
                            <div class="radioGroup"> <span class="genderRadio"><input class="form-check-input" type="radio" name="request_condition" id="" value="Unworn"> 0 Unworn
                                
                                </span> <span class="genderRadio"><input class="form-check-input" type="radio" name="request_condition" id="" value="Mint"> 1 Mint
                                
                                </span> <span class="genderRadio"> <input class="form-check-input" type="radio" name="request_condition" id="" value="Excellent "> 2 Excellent
                               
                                </span> <span class="genderRadio"> <input class="form-check-input" type="radio" name="request_condition" id="" value="Good  "> 3 Good
                               
                                </span> <span class="genderRadio"><input class="form-check-input" type="radio" name="request_condition" id="" value="Fair "> 4 Fair
                                
                                </span> <span class="genderRadio"><input class="form-check-input" type="radio" name="request_condition" id="" value="poor  "> 5 poor
                                
                                </span> </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Country">Country of the requester :</label>
                        <div class="inputBox">
                             <select name="req_country" class="form-control" tabindex="12" id="reg_field_company_country"><option value="Afghanistan">Afghanistan</option><option value="Albania">Albania</option><option value="Algeria">Algeria</option><option value="Andorra">Andorra</option><option value="Angola">Angola</option><option value="Anguilla">Anguilla</option><option value="Antigua &amp; Barbuda">Antigua &amp; Barbuda</option><option value="Argentina">Argentina</option><option value="Armenia">Armenia</option><option value="Australia">Australia</option><option value="Austria">Austria</option><option value="Azerbaijan">Azerbaijan</option><option value="Bahamas">Bahamas</option><option value="Bahrain">Bahrain</option><option value="Bangladesh">Bangladesh</option><option value="Barbados">Barbados</option><option value="Belarus">Belarus</option><option value="Belgium">Belgium</option><option value="Belize">Belize</option><option value="Benin">Benin</option><option value="Bermuda">Bermuda</option><option value="Bhutan">Bhutan</option><option value="Bolivia">Bolivia</option><option value="Bosnia &amp; Herzegovina">Bosnia &amp; Herzegovina</option><option value="Botswana">Botswana</option><option value="Brazil">Brazil</option><option value="Brunei Darussalam">Brunei Darussalam</option><option value="Bulgaria">Bulgaria</option><option value="Burkina Faso">Burkina Faso</option><option value="Myanmar/Burma">Myanmar/Burma</option><option value="Burundi">Burundi</option><option value="Cambodia">Cambodia</option><option value="Cameroon">Cameroon</option><option value="Canada">Canada</option><option value="Cape Verde">Cape Verde</option><option value="Cayman Islands">Cayman Islands</option><option value="Central African Republic">Central African Republic</option><option value="Chad">Chad</option><option value="Chile">Chile</option><option value="China">China</option><option value="" selected="selected"></option><option value="Colombia">Colombia</option><option value="Comoros">Comoros</option><option value="Congo">Congo</option><option value="Costa Rica">Costa Rica</option><option value="Croatia">Croatia</option><option value="Cuba">Cuba</option><option value="Cyprus">Cyprus</option><option value="Czech Republic">Czech Republic</option><option value="Democratic Republic of the Congo">Democratic Republic of the Congo</option><option value="Denmark">Denmark</option><option value="Djibouti">Djibouti</option><option value="Dominican Republic">Dominican Republic</option><option value="Dominica">Dominica</option><option value="Ecuador">Ecuador</option><option value="Egypt">Egypt</option><option value="El Salvador">El Salvador</option><option value="Equatorial Guinea">Equatorial Guinea</option><option value="Eritrea">Eritrea</option><option value="Estonia">Estonia</option><option value="Ethiopia">Ethiopia</option><option value="Fiji">Fiji</option><option value="Finland">Finland</option><option value="France">France</option><option value="French Guiana">French Guiana</option><option value="Gabon">Gabon</option><option value="Gambia">Gambia</option><option value="Georgia">Georgia</option><option value="Germany">Germany</option><option value="Ghana">Ghana</option><option value="Great Britain">Great Britain</option><option value="Greece">Greece</option><option value="Grenada">Grenada</option><option value="Guadeloupe">Guadeloupe</option><option value="Guatemala">Guatemala</option><option value="Guinea">Guinea</option><option value="Guinea-Bissau">Guinea-Bissau</option><option value="Guyana">Guyana</option><option value="Haiti">Haiti</option><option value="Honduras">Honduras</option><option value="Hungary">Hungary</option><option value="" selected="selected"></option><option value="Iceland">Iceland</option><option value="India">India</option><option value="Indonesia">Indonesia</option><option value="Iran">Iran</option><option value="Iraq">Iraq</option><option value="Israel and the Occupied Territories">Israel and the Occupied Territories</option><option value="Italy">Italy</option><option value="Ivory Coast (Cote d\'Ivoire)">Ivory Coast (Cote d\'Ivoire)</option><option value="Jamaica">Jamaica</option><option value="Japan">Japan</option><option value="Jordan">Jordan</option><option value="Kazakhstan">Kazakhstan</option><option value="Kenya">Kenya</option><option value="Kosovo">Kosovo</option><option value="Kuwait">Kuwait</option><option value="Kyrgyz Republic (Kyrgyzstan)">Kyrgyz Republic (Kyrgyzstan)</option><option value="Laos">Laos</option><option value="Latvia">Latvia</option><option value="Lebanon">Lebanon</option><option value="Lesotho">Lesotho</option><option value="Liberia">Liberia</option><option value="Libya">Libya</option><option value="Liechtenstein">Liechtenstein</option><option value="Lithuania">Lithuania</option><option value="Luxembourg">Luxembourg</option><option value="Republic of Macedonia">Republic of Macedonia</option><option value="Madagascar">Madagascar</option><option value="Malawi">Malawi</option><option value="Malaysia">Malaysia</option><option value="Maldives">Maldives</option><option value="Mali">Mali</option><option value="Malta">Malta</option><option value="Martinique">Martinique</option><option value="Mauritania">Mauritania</option><option value="Mauritius">Mauritius</option><option value="Mayotte">Mayotte</option><option value="Mexico">Mexico</option><option value="Moldova, Republic of">Moldova, Republic of</option><option value="Monaco">Monaco</option><option value="Mongolia">Mongolia</option><option value="" selected="selected"></option><option value="Montenegro">Montenegro</option><option value="Montserrat">Montserrat</option><option value="Morocco">Morocco</option><option value="Mozambique">Mozambique</option><option value="Namibia">Namibia</option><option value="Nepal">Nepal</option><option value="Netherlands">Netherlands</option><option value="New Zealand">New Zealand</option><option value="Nicaragua">Nicaragua</option><option value="Niger">Niger</option><option value="Nigeria">Nigeria</option><option value="Korea, Democratic Republic of (North Korea)">Korea, Democratic Republic of (North Korea)</option><option value="Norway">Norway</option><option value="Oman">Oman</option><option value="Pacific Islands">Pacific Islands</option><option value="Pakistan">Pakistan</option><option value="Panama">Panama</option><option value="Papua New Guinea">Papua New Guinea</option><option value="Paraguay">Paraguay</option><option value="Peru">Peru</option><option value="Philippines">Philippines</option><option value="Poland">Poland</option><option value="Portugal">Portugal</option><option value="Puerto Rico">Puerto Rico</option><option value="Qatar">Qatar</option><option value="Reunion">Reunion</option><option value="Romania">Romania</option><option value="Russian Federation">Russian Federation</option><option value="Rwanda">Rwanda</option><option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option><option value="Saint Lucia">Saint Lucia</option><option value="Saint Vincent\'s &amp; Grenadines">Saint Vincent\'s &amp; Grenadines</option><option value="Samoa">Samoa</option><option value="Sao Tome and Principe">Sao Tome and Principe</option><option value="Saudi Arabia">Saudi Arabia</option><option value="Senegal">Senegal</option><option value="Serbia">Serbia</option><option value="Seychelles">Seychelles</option><option value="Sierra Leone">Sierra Leone</option><option value="Singapore">Singapore</option><option value="" selected="selected"></option><option value="Slovak Republic (Slovakia)">Slovak Republic (Slovakia)</option><option value="Slovenia">Slovenia</option><option value="Solomon Islands">Solomon Islands</option><option value="Somalia">Somalia</option><option value="South Africa">South Africa</option><option value="Korea, Republic of (South Korea)">Korea, Republic of (South Korea)</option><option value="South Sudan">South Sudan</option><option value="Spain">Spain</option><option value="Sri Lanka">Sri Lanka</option><option value="Sudan">Sudan</option><option value="Suriname">Suriname</option><option value="Swaziland">Swaziland</option><option value="Sweden">Sweden</option><option value="Switzerland">Switzerland</option><option value="Syria">Syria</option><option value="Tajikistan">Tajikistan</option><option value="Tanzania">Tanzania</option><option value="Thailand">Thailand</option><option value="Timor Leste">Timor Leste</option><option value="Togo">Togo</option><option value="Trinidad &amp; Tobago">Trinidad &amp; Tobago</option><option value="Tunisia">Tunisia</option><option value="Turkey">Turkey</option><option value="Turkmenistan">Turkmenistan</option><option value="Turks &amp; Caicos Islands">Turks &amp; Caicos Islands</option><option value="Uganda">Uganda</option><option value="Ukraine">Ukraine</option><option value="United Arab Emirates">United Arab Emirates</option><option value="United States of America (USA)">United States of America (USA)</option><option value="Uruguay">Uruguay</option><option value="Uzbekistan">Uzbekistan</option><option value="Venezuela">Venezuela</option><option value="Vietnam">Vietnam</option><option value="Virgin Islands (UK)">Virgin Islands (UK)</option><option value="Virgin Islands (US)">Virgin Islands (US)</option><option value="Yemen">Yemen</option><option value="Zambia">Zambia</option><option value="Zimbabwe">Zimbabwe</option></select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Datestarts">Date when request starts :</label>
                        <div class="inputBox">
                            <input type="text" name="request_date" class="form-control" id="datepicker" placeholder="start date dd/mm/yy">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Dateends">Days after request ends:</label>
                        <div class="inputBox">
                           <input type="text" name="request_existance" class="form-control" id="" placeholder="1-30 ">
                          
                        </div>
                    </div>
                    <input type="submit" class="" name="submit" value="Send">
                </form>
            
            </div>
		</div>
   
   </div>
   </div>
   
   
    </div>
</div>

<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery('.requestSearch').click(function(){
			var year = jQuery('.year_data').val();
			var brand = jQuery('.brand_data option:selected').val();
			var ref_no = jQuery('.ref_no_data').val();
			var category = jQuery('.category_data option:selected').val();
			var model = jQuery('.model_data').val();
			if(brand == ''){
				jQuery('.brand_data').addClass('error');
				return false;
			}
			jQuery.ajax({
				method : 'post',
				data: {year: year, brand: brand, ref_no :ref_no, category: category, model: model},
				url: '<?php echo get_stylesheet_directory_uri();?>/request.php',
				success: function(data) {
					if(data != 0 ){
						jQuery('.wlt_search_results').html(data);
					}else{
						jQuery('.request_Form').css('display','block');
					}
				},

			});
			
		});
		
		jQuery('.brand_data.error').click(function(){
			jQuery(this).removeClass('error');
		});
	});


</script>
<?php  hook_page_after(); ?>
<?php endwhile; endif; ?>
<?php get_footer($CORE->pageswitch());


} ?>
