<?php include '../../../wp-load.php'; ?>
<?php
	$search = $_POST['searchtext'];
	$country = $_POST['country'];
	//print_r($country);
	if($country == 'All countries'){
		$country = '';
	}
	$args =array(
				'meta_query' => array(
					'relation' => 'AND',
							array(
								'key'     => 'comppany_country',
								'value'   => $country,
								//'value'   => $country,
								'compare' => 'LIKE',
							),
							array(
									'relation' => 'OR',
									array(
											'key' => 'company_city',
											'value' => $search,
											'compare' => 'LIKE',
									),
									array(
											'key' => 'comppany_country',
											'value' => $search,
											'compare' => 'LIKE',
									),
									array(
											'key' => 'postcode',
											'value' => $search,
											'compare' => '=',
									),
									array(
											'key' => 'company_name',
											'value' => $search,
											'compare' => 'LIKE',
									),
					),
				),
			);
	$blogusers = get_users($args);
	//echo $wpdb->last_query;
	//print_r($blogusers);
if(!empty($blogusers)){
	foreach($blogusers as $users){
	$user = get_user_by('id', $users->ID);
  ?>
  <div class="paginContent">
  <div class="country_info">
    <div class="col-md-12">
      <div class="col-md-6">
        <h4><a href=<?php echo site_url().'/single-dealer?dealer_id='.$users->ID;?>><?php if(get_user_meta($users->ID,'company_name',true) != ''){echo get_user_meta($users->ID,'company_name',true);} else{echo "Not Exist";}?></a></h4>
        <ul>
          <li><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/flag.png"/></li>
          <li><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/home.png"/></li>
          <li><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/checked.png"/><span>433</span></li>
          <li><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/ribbon.png"/><span>2005</span></li>
          <li><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/star.png"/><span>37</span></li>
        </ul>
      </div>
      <div class="col-md-6"> <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/cmpny_logo.png"/>
        <address>
        <?php //echo get_user_meta($users->ID,'company_address',true);?><br>
        <?php if(get_user_meta($users->ID,'house_no',true) !=''){echo get_user_meta($users->ID,'house_no',true).',';}?><?php if(get_user_meta($users->ID,'street_name',true) !=''){echo get_user_meta($users->ID,'street_name',true).',';}?><?php if(get_user_meta($users->ID,'company_city',true) !=''){echo get_user_meta($users->ID,'company_city',true).',';}?><br>
        <?php if(get_user_meta($users->ID,'company_country',true) !=''){echo get_user_meta($users->ID,'company_country',true).',';}?><?php if(get_user_meta($users->ID,'postcode',true) !=''){echo get_user_meta($users->ID,'postcode',true).',';}?>
        </address>
      </div>
     <!-- <div col-md-12><a href="#"><i class="fa fa-angle-right" aria-hidden="true"></i> Our Supply of Wacthes</a></div>-->
    </div>
  </div>
  </div>
 <?php } 
}
else{
	echo "No dealer found. Please try with some other filters";
	
	}

